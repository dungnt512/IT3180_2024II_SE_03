package com.example.demo.enums;

public enum ApartmentStatus {
    OCCUPIED, VACANT, RENT
}