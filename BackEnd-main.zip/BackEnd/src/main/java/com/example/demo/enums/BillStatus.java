package com.example.demo.enums;

public enum BillStatus {
    UNPAID, PAID
}
