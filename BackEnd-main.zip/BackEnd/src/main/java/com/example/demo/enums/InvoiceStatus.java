package com.example.demo.enums;

public enum InvoiceStatus {
    UNPAID, 
    PAID,  
    FAILED,
    REFUNDED
} 