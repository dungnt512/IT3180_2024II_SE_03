package com.example.demo.enums;

public enum ParkingLotStatus {
    AVAILABLE,   // Chỗ đỗ xe chưa có người thuê
    RENTED;      // Chỗ đỗ xe đã có người thuê
}