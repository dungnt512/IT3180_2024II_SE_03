package com.example.demo.enums;

public enum ParkingType {
    CAR,
    MOTORBIKE
}