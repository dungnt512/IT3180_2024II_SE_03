package com.example.demo.enums;

public enum Role {
    ADMIN, RESIDENT
}

