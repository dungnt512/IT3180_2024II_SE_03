package com.example.demo.enums;

public enum BillType {
    FIXED_COST, SERVICE_COST
}
